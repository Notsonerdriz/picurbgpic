(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const DEFAULT_LINKS = [
    { name: "YouTube", url: "https://www.youtube.com/" },
    { name: "GitHub", url: "https://github.com/" },
    { name: "Wikipedia", url: "https://www.wikipedia.org/" },
    { name: "ChatGPT", url: "https://chatgpt.com/" },
    { name: "Gmail", url: "https://mail.google.com/" }
  ];
  const DEFAULTS = {
    wallpaperPreset: "default",
    customWallpaper: "",
    accent: "#2878b8",
    searchEngine: "google",
    customEngines: [],
    customLinks: []
  };
  const PRESETS = {
    default: "linear-gradient(135deg, #d8edf8 0%, #9fc9e2 48%, #dcecf5 100%)",
    sky: "linear-gradient(135deg, #e5f5ff 0%, #b7def2 52%, #f3fbff 100%)",
    silver: "linear-gradient(135deg, #eef1f4 0%, #cbd5dc 50%, #f8fafb 100%)",
    night: "linear-gradient(135deg, #203d5c 0%, #315d7e 52%, #172f49 100%)"
  };
  const SEARCH_URLS = {
    google: "https://www.google.com/search?q=",
    bing: "https://www.bing.com/search?q=",
    duckduckgo: "https://duckduckgo.com/?q="
  };

  let settings = { ...DEFAULTS };
  const storage = {
    async get() {
      if (globalThis.chrome?.storage?.local) {
        return await chrome.storage.local.get(DEFAULTS);
      }
      try { return JSON.parse(localStorage.getItem("picurbgpic-settings") || "{}"); }
      catch { return {}; }
    },
    async set(values) {
      if (globalThis.chrome?.storage?.local) {
        await chrome.storage.local.set(values);
      } else {
        settings = { ...settings, ...values };
        localStorage.setItem("picurbgpic-settings", JSON.stringify(settings));
      }
    }
  };

  function safeHttpUrl(value) {
    try {
      const url = new URL(value);
      return url.protocol === "https:" || url.protocol === "http:";
    } catch { return false; }
  }

  function showStatus(message, isError = false) {
    const el = $("settings-status");
    if (!el) return;
    el.textContent = message;
    el.style.color = isError ? "#9b3030" : "#28633e";
  }

  async function save(patch, message = "Settings saved.") {
    settings = { ...settings, ...patch };
    try {
      await storage.set(patch);
      showStatus(message);
    } catch (error) {
      console.error("PicUrBGPic could not save settings:", error);
      showStatus("Could not save. Check available extension storage.", true);
    }
  }

  function applyAppearance() {
    document.documentElement.style.setProperty("--accent", settings.accent || DEFAULTS.accent);
    const wallpaper = $("wallpaper");
    if (settings.customWallpaper) {
      wallpaper.style.backgroundImage = `url("${settings.customWallpaper}")`;
    } else {
      wallpaper.style.backgroundImage = PRESETS[settings.wallpaperPreset] || PRESETS.default;
    }
    $("wallpaper-preset").value = settings.wallpaperPreset || "default";
    $("accent-color").value = settings.accent || DEFAULTS.accent;
  }

  function updateClock() {
    const now = new Date();
    $("clock").textContent = new Intl.DateTimeFormat(undefined, {
      hour: "2-digit", minute: "2-digit", hour12: true
    }).format(now);
    $("date").textContent = new Intl.DateTimeFormat(undefined, {
      weekday: "long", year: "numeric", month: "long", day: "numeric"
    }).format(now);
    const hour = now.getHours();
    $("greeting").textContent = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
  }

  function makeLink(link, index, isCustom) {
    const anchor = document.createElement("a");
    anchor.className = "quick-link";
    anchor.href = link.url;
    anchor.target = "_blank";
    anchor.rel = "noopener noreferrer";
    const icon = document.createElement("span");
    icon.className = "link-icon";
    icon.textContent = (link.name.trim()[0] || "?").toUpperCase();
    const label = document.createElement("span");
    label.className = "link-label";
    label.textContent = link.name;
    anchor.append(icon, label);
    if (isCustom) anchor.dataset.customIndex = String(index);
    return anchor;
  }

  function renderLinks() {
    const container = $("quick-links");
    container.replaceChildren();
    const links = [...DEFAULT_LINKS, ...(settings.customLinks || [])];
    links.forEach((link, index) => container.append(makeLink(link, index, index >= DEFAULT_LINKS.length)));
  }

  function renderSettingsLists() {
    const engineList = $("custom-engines-list");
    engineList.replaceChildren();
    (settings.customEngines || []).forEach((engine, index) => {
      const li = document.createElement("li");
      const label = document.createElement("span");
      label.textContent = `${engine.name} — custom search`;
      const remove = document.createElement("button");
      remove.className = "remove-button";
      remove.type = "button";
      remove.textContent = "Remove";
      remove.addEventListener("click", async () => {
        const next = settings.customEngines.filter((_, i) => i !== index);
        await save({ customEngines: next }, "Search engine removed.");
        renderSearchOptions();
        renderSettingsLists();
      });
      li.append(label, remove);
      engineList.append(li);
    });

    const linkList = $("custom-links-list");
    linkList.replaceChildren();
    (settings.customLinks || []).forEach((link, index) => {
      const li = document.createElement("li");
      const label = document.createElement("span");
      label.textContent = `${link.name} — ${link.url}`;
      const remove = document.createElement("button");
      remove.className = "remove-button";
      remove.type = "button";
      remove.textContent = "Remove";
      remove.addEventListener("click", async () => {
        const next = settings.customLinks.filter((_, i) => i !== index);
        await save({ customLinks: next }, "Quick link removed.");
        renderLinks();
        renderSettingsLists();
      });
      li.append(label, remove);
      linkList.append(li);
    });
  }

  function renderSearchOptions() {
    const select = $("search-engine");
    const current = settings.searchEngine || "google";
    select.replaceChildren();
    [["google", "Google"], ["bing", "Bing"], ["duckduckgo", "DuckDuckGo"]]
      .forEach(([value, label]) => {
        const option = document.createElement("option");
        option.value = value;
        option.textContent = label;
        select.append(option);
      });
    (settings.customEngines || []).forEach((engine, index) => {
      const option = document.createElement("option");
      option.value = `custom:${index}`;
      option.textContent = engine.name;
      select.append(option);
    });
    select.value = [...select.options].some(option => option.value === current) ? current : "google";
  }

  function openSettings() {
    $("settings-overlay").hidden = false;
    $("settings-dialog").hidden = false;
    $("close-settings").focus();
  }
  function closeSettings() {
    $("settings-overlay").hidden = true;
    $("settings-dialog").hidden = true;
    $("open-settings").focus();
  }

  function bindEvents() {
    $("open-settings").addEventListener("click", openSettings);
    $("close-settings").addEventListener("click", closeSettings);
    $("settings-overlay").addEventListener("click", closeSettings);
    document.addEventListener("keydown", event => {
      if (event.key === "Escape" && !$("settings-dialog").hidden) closeSettings();
    });

    $("search-engine").addEventListener("change", async event => {
      settings.searchEngine = event.target.value;
      await save({ searchEngine: settings.searchEngine });
    });
    $("search-form").addEventListener("submit", event => {
      event.preventDefault();
      const query = $("search-input").value.trim();
      if (!query) return;
      const engine = $("search-engine").value;
      if (engine.startsWith("custom:")) {
        const index = Number(engine.split(":")[1]);
        const custom = settings.customEngines[index];
        if (!custom) return;
        window.location.assign(custom.url.replaceAll("{query}", encodeURIComponent(query)));
      } else {
        window.location.assign((SEARCH_URLS[engine] || SEARCH_URLS.google) + encodeURIComponent(query));
      }
    });

    $("wallpaper-preset").addEventListener("change", async event => {
      await save({ wallpaperPreset: event.target.value, customWallpaper: "" }, "Wallpaper updated.");
      applyAppearance();
    });
    $("wallpaper-upload").addEventListener("change", async event => {
      const file = event.target.files?.[0];
      if (!file) return;
      if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
        showStatus("Please choose a JPG, PNG or WebP image.", true);
        event.target.value = "";
        return;
      }
      if (file.size > 3 * 1024 * 1024) {
        showStatus("Image is too large. Maximum size is 3 MB.", true);
        event.target.value = "";
        return;
      }
      const reader = new FileReader();
      reader.onload = async () => {
        await save({ customWallpaper: String(reader.result), wallpaperPreset: "default" }, "Custom wallpaper applied.");
        applyAppearance();
      };
      reader.onerror = () => showStatus("Could not read that image.", true);
      reader.readAsDataURL(file);
    });
    $("reset-wallpaper").addEventListener("click", async () => {
      await save({ customWallpaper: "", wallpaperPreset: "default" }, "Wallpaper reset.");
      $("wallpaper-upload").value = "";
      applyAppearance();
    });
    $("accent-color").addEventListener("input", async event => {
      settings.accent = event.target.value;
      document.documentElement.style.setProperty("--accent", settings.accent);
      await save({ accent: settings.accent }, "Accent color saved.");
    });

    $("engine-form").addEventListener("submit", async event => {
      event.preventDefault();
      const name = $("engine-name").value.trim();
      const url = $("engine-url").value.trim();
      if (!name || !url.includes("{query}") || !safeHttpUrl(url.replaceAll("{query}", "test"))) {
        showStatus("Enter a valid HTTP(S) search URL containing {query}.", true);
        return;
      }
      const next = [...(settings.customEngines || []), { name, url }];
      await save({ customEngines: next }, "Search engine added.");
      event.target.reset();
      renderSearchOptions();
      renderSettingsLists();
    });

    $("link-form").addEventListener("submit", async event => {
      event.preventDefault();
      const name = $("link-name").value.trim();
      const url = $("link-url").value.trim();
      if (!name || !safeHttpUrl(url)) {
        showStatus("Enter a valid HTTP or HTTPS link.", true);
        return;
      }
      const next = [...(settings.customLinks || []), { name, url }];
      await save({ customLinks: next }, "Quick link added.");
      event.target.reset();
      renderLinks();
      renderSettingsLists();
    });
  }

  async function init() {
    try {
      const saved = await storage.get();
      settings = { ...DEFAULTS, ...saved };
    } catch (error) {
      console.error("PicUrBGPic settings could not be loaded:", error);
      settings = { ...DEFAULTS };
    }
    applyAppearance();
    updateClock();
    window.setInterval(updateClock, 1000);
    renderSearchOptions();
    renderLinks();
    renderSettingsLists();
    bindEvents();
  }

  document.addEventListener("DOMContentLoaded", init, { once: true });
})();
